"""
BikeWorth core: data preparation, feature building, model training and prediction.

Shared by train_model.py (offline training) and app.py (the Streamlit app).
Follows Chapter 5 of the report:
  * age is derived from model year
  * categorical fields are one-hot encoded
  * six numeric fields are standardised with training means / standard deviations
  * missing ex-showroom prices are imputed (brand median of the training rows)
  * the final model is a Random Forest: 200 trees, max depth 18, min 2 listings per leaf
  * the likely range is the 10th-90th percentile of the 200 tree outputs
"""
from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score, train_test_split, KFold
from sklearn.neighbors import KNeighborsRegressor
from sklearn.tree import DecisionTreeRegressor

ROOT = Path(__file__).resolve().parent
DATA_RAW = ROOT / "data" / "used_bikes_raw.csv"
DATA_CLEAN = ROOT / "data" / "used_bikes.csv"
MODEL_PATH = ROOT / "model" / "bikeworth_model.joblib"
METRICS_PATH = ROOT / "model" / "metrics.json"

REFERENCE_YEAR = 2026
TARGET = "selling_price"
NUMERIC = ["age_years", "km_driven", "engine_cc", "max_power_bhp",
           "ex_showroom_price", "condition_rating"]
CATEGORICAL = ["brand", "owner_type", "seller_type", "fuel_type"]
RANDOM_STATE = 42

# Allowed input ranges (taken from the dataset, Table 8.3)
INPUT_RANGES = {
    "model_year": (2004, 2025),
    "km_driven": (0, 300000),
    "engine_cc": (90, 1300),
    "max_power_bhp": (4.0, 200.0),
    "ex_showroom_price": (30000, 1500000),
    "condition_rating": (1, 5),
}

MODELS = {
    "Linear Regression": lambda: LinearRegression(),
    "Ridge Regression": lambda: Ridge(alpha=1.0),
    "KNN (K = 7)": lambda: KNeighborsRegressor(n_neighbors=7),
    "Decision Tree": lambda: DecisionTreeRegressor(max_depth=5, min_samples_leaf=20,
                                                   random_state=RANDOM_STATE),
    "Random Forest": lambda: RandomForestRegressor(
        n_estimators=200, max_depth=18, min_samples_leaf=2,
        n_jobs=-1, random_state=RANDOM_STATE),
    "Gradient Boosting": lambda: GradientBoostingRegressor(
        n_estimators=120, learning_rate=0.06, max_depth=3, subsample=0.8,
        random_state=RANDOM_STATE),
}


# --------------------------------------------------------------------------
# Data preparation
# --------------------------------------------------------------------------
def prepare_data(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Remove exact duplicates and add the derived age field. Returns (clean, info)."""
    n_raw = len(raw)
    clean = raw.drop_duplicates().reset_index(drop=True)
    info = {"raw_records": int(n_raw),
            "duplicates_removed": int(n_raw - len(clean))}
    if "age_years" not in clean.columns:
        clean.insert(4, "age_years", REFERENCE_YEAR - clean["model_year"])
    return clean, info


# --------------------------------------------------------------------------
# Feature building
# --------------------------------------------------------------------------
def build_preprocessor(train: pd.DataFrame) -> dict:
    """Learn everything needed to turn a listing into a model input row."""
    brand_ex_median = (train.groupby("brand")["ex_showroom_price"].median()
                       .dropna().to_dict())
    global_ex_median = float(train["ex_showroom_price"].median())
    filled = train.copy()
    filled["ex_showroom_price"] = filled.apply(
        lambda r: r["ex_showroom_price"] if pd.notna(r["ex_showroom_price"])
        else brand_ex_median.get(r["brand"], global_ex_median), axis=1)
    scaler = {c: (float(filled[c].mean()), float(filled[c].std(ddof=0)))
              for c in NUMERIC}
    categories = {c: sorted(train[c].unique().tolist()) for c in CATEGORICAL}
    columns = list(NUMERIC)
    for c in CATEGORICAL:
        columns += [f"{c}={v}" for v in categories[c]]
    return {"brand_ex_median": brand_ex_median, "global_ex_median": global_ex_median,
            "scaler": scaler, "categories": categories, "columns": columns}


def build_features(df: pd.DataFrame, prep: dict, impute_ex: bool = True,
                   drop_ex: bool = False) -> pd.DataFrame:
    d = df.copy()
    if "age_years" not in d.columns:
        d["age_years"] = REFERENCE_YEAR - d["model_year"]
    if impute_ex:
        d["ex_showroom_price"] = [
            v if pd.notna(v) else prep["brand_ex_median"].get(b, prep["global_ex_median"])
            for v, b in zip(d["ex_showroom_price"], d["brand"])]
    out = pd.DataFrame(index=d.index)
    for c in NUMERIC:
        mean, std = prep["scaler"][c]
        out[c] = (d[c].astype(float) - mean) / (std if std else 1.0)
    for c in CATEGORICAL:
        for v in prep["categories"][c]:
            out[f"{c}={v}"] = (d[c] == v).astype(float)
    out = out[prep["columns"]]
    if drop_ex:
        out = out.drop(columns=["ex_showroom_price"])
    return out


# --------------------------------------------------------------------------
# Training and evaluation
# --------------------------------------------------------------------------
def _mape(y, p):
    y = np.asarray(y, float)
    return float(np.mean(np.abs(y - p) / y) * 100)


def band_of(price: float) -> str:
    if price < 30000:
        return "Under Rs. 30,000"
    if price < 80000:
        return "Rs. 30,000 to 80,000"
    return "Rs. 80,000 and above"


def train_all(clean: pd.DataFrame, info: dict | None = None) -> tuple[dict, dict]:
    """Train the six models on 4,000 rows, test on 1,000, return (artifact, metrics)."""
    train, test = train_test_split(clean, train_size=4000, test_size=1000,
                                   random_state=RANDOM_STATE)
    prep = build_preprocessor(train)
    Xtr, Xte = build_features(train, prep), build_features(test, prep)
    ytr, yte = train[TARGET].values, test[TARGET].values
    kf = KFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)

    results, fitted = {}, {}
    for name, make in MODELS.items():
        model = make().fit(Xtr, ytr)
        pred = model.predict(Xte)
        cv = cross_val_score(make(), Xtr, ytr, cv=kf, scoring="r2",
                             n_jobs=1).mean()
        results[name] = {
            "MAE": float(mean_absolute_error(yte, pred)),
            "RMSE": float(np.sqrt(mean_squared_error(yte, pred))),
            "R2": float(r2_score(yte, pred)),
            "R2_CV": float(cv),
            "MAPE": _mape(yte, pred),
        }
        fitted[name] = model

    rf = fitted["Random Forest"]
    pred = rf.predict(Xte)
    ape = np.abs(yte - pred) / yte * 100
    counts = clean["brand"].value_counts()
    rare = set(counts[counts < 100].index)
    bands = np.array([band_of(p) for p in yte])
    seg = {b: float(ape[bands == b].mean()) for b in
           ["Under Rs. 30,000", "Rs. 30,000 to 80,000", "Rs. 80,000 and above"]}
    seg["Brands with fewer than 100 listings"] = float(
        ape[test["brand"].isin(rare).values].mean())

    # feature importance grouped to the names used in the report
    imp = dict(zip(prep["columns"], rf.feature_importances_))
    grouped = {
        "Age of bike": imp["age_years"],
        "Ex-showroom price": imp["ex_showroom_price"],
        "Max power": imp["max_power_bhp"],
        "Km driven": imp["km_driven"],
        "Brand": sum(v for k, v in imp.items() if k.startswith("brand=")),
        "Engine (cc)": imp["engine_cc"],
        "Condition rating": imp["condition_rating"],
        "Owner type": sum(v for k, v in imp.items() if k.startswith("owner_type=")),
        "Seller type": sum(v for k, v in imp.items() if k.startswith("seller_type=")),
        "Fuel type": sum(v for k, v in imp.items() if k.startswith("fuel_type=")),
    }
    grouped = dict(sorted(grouped.items(), key=lambda kv: -kv[1]))
    top3 = grouped["Age of bike"] + grouped["Ex-showroom price"] + grouped["Max power"]

    # model without the ex-showroom field (finding 4 of the report)
    rf_no_ex = MODELS["Random Forest"]().fit(build_features(train, prep, drop_ex=True), ytr)
    r2_no_ex = float(r2_score(yte, rf_no_ex.predict(
        build_features(test, prep, drop_ex=True))))

    # correlations (Section 6.2)
    has_ex = clean["ex_showroom_price"].notna()
    corr = {
        "age_vs_price": float(clean["age_years"].corr(clean[TARGET])),
        "ex_vs_price": float(clean.loc[has_ex, "ex_showroom_price"]
                             .corr(clean.loc[has_ex, TARGET])),
        "power_vs_price": float(clean["max_power_bhp"].corr(clean[TARGET])),
        "n_with_ex": int(has_ex.sum()),
    }

    metrics = {
        "models": results,
        "segments_mape": seg,
        "importance": grouped,
        "top3_importance_share": float(top3),
        "rf_r2_without_ex_showroom": r2_no_ex,
        "correlations": corr,
        "n_train": int(len(train)), "n_test": int(len(test)),
        "data_info": info or {},
        "scaler": prep["scaler"],
        "rf_params": {"n_estimators": 200, "max_depth": 18, "min_samples_leaf": 2},
    }
    artifact = {"rf": rf, "prep": prep, "brand_counts": counts.to_dict(),
                "train_index": train.index.tolist()}
    return artifact, metrics


def save_artifacts(artifact: dict, metrics: dict) -> None:
    MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump(artifact, MODEL_PATH, compress=3)
    METRICS_PATH.write_text(json.dumps(metrics, indent=2))


def load_artifacts() -> tuple[dict, dict]:
    return joblib.load(MODEL_PATH), json.loads(METRICS_PATH.read_text())


# --------------------------------------------------------------------------
# Prediction
# --------------------------------------------------------------------------
def validate_inputs(inp: dict) -> list[str]:
    """Return a list of problems with the user's inputs (empty list = valid)."""
    problems = []
    names = {"model_year": "Model year", "km_driven": "Km driven",
             "engine_cc": "Engine (cc)", "max_power_bhp": "Max power (bhp)",
             "ex_showroom_price": "Ex-showroom price", "condition_rating": "Condition rating"}
    for key, (lo, hi) in INPUT_RANGES.items():
        v = inp.get(key)
        if v is None or (isinstance(v, float) and np.isnan(v)):
            problems.append(f"{names[key]} is missing.")
        elif not (lo <= v <= hi):
            problems.append(f"{names[key]} must be between {lo:,} and {hi:,}.")
    return problems


def predict_price(artifact: dict, inp: dict) -> dict:
    """Estimate = mean of the 200 trees; range = 10th to 90th percentile of the trees."""
    prep, rf = artifact["prep"], artifact["rf"]
    row = pd.DataFrame([{
        "brand": inp["brand"], "model_year": inp["model_year"],
        "age_years": REFERENCE_YEAR - inp["model_year"],
        "km_driven": inp["km_driven"], "owner_type": inp["owner_type"],
        "seller_type": inp["seller_type"], "fuel_type": inp["fuel_type"],
        "engine_cc": inp["engine_cc"], "max_power_bhp": inp["max_power_bhp"],
        "ex_showroom_price": inp["ex_showroom_price"],
        "condition_rating": inp["condition_rating"]}])
    X = build_features(row, prep).values
    tree_out = np.array([t.predict(X)[0] for t in rf.estimators_])
    est = float(tree_out.mean())
    lo, hi = np.percentile(tree_out, [10, 90])
    r100 = lambda v: int(round(v / 100.0) * 100)
    return {"estimate": r100(est), "low": r100(lo), "high": r100(hi),
            "brand_listings": int(artifact["brand_counts"].get(inp["brand"], 0))}


def similar_listings(clean: pd.DataFrame, inp: dict, k: int = 3) -> pd.DataFrame:
    """Nearest listings of the same brand by age, kilometres and engine size."""
    d = clean[clean["brand"] == inp["brand"]].copy()
    if d.empty:
        d = clean.copy()
    age = REFERENCE_YEAR - inp["model_year"]
    dist = (((d["age_years"] - age) / 2.0) ** 2
            + ((d["km_driven"] - inp["km_driven"]) / 15000.0) ** 2
            + ((d["engine_cc"] - inp["engine_cc"]) / 30.0) ** 2
            + ((d["max_power_bhp"] - inp["max_power_bhp"]) / 4.0) ** 2
            + 0.5 * (d["condition_rating"] - inp["condition_rating"]) ** 2)
    ex = inp.get("ex_showroom_price")
    if ex:  # listings with an unknown ex-showroom price are compared on the other fields only
        dist = dist + (((d["ex_showroom_price"] - ex) / 8000.0) ** 2).fillna(1.0)
    return d.assign(_d=dist).sort_values("_d").head(k).drop(columns="_d")


# --------------------------------------------------------------------------
# Display helpers
# --------------------------------------------------------------------------
def inr(n: float) -> str:
    """Format a number with Indian digit grouping: 1,03,700."""
    n = int(round(n))
    sign = "-" if n < 0 else ""
    s = str(abs(n))
    if len(s) <= 3:
        return sign + s
    head, tail = s[:-3], s[-3:]
    parts = []
    while len(head) > 2:
        parts.insert(0, head[-2:])
        head = head[:-2]
    if head:
        parts.insert(0, head)
    return sign + ",".join(parts) + "," + tail
