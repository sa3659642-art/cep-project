# BikeWorth: Used Bike Price Prediction Analysis Using Machine Learning

Streamlit app for the B.Sc. Data Science Community Engagement Project (2026-27).
Six pages, as in the report: Home, Dataset Explorer, Insights, Price Predictor,
Model Comparison, Download and Help.

## Run it

```bash
pip install -r requirements.txt
streamlit run app.py
```

The dataset (`data/used_bikes.csv`) and the trained model (`model/`) are included, so the
app starts straight away. No internet is needed once the libraries are installed.
If either file is missing, or the saved model cannot be loaded by your scikit-learn
version, the app rebuilds it automatically on first start (about 15 seconds).

## Files

| File | What it does |
|---|---|
| `app.py` | The Streamlit app (all six pages) |
| `bikeworth_core.py` | Feature building, training of the six models, prediction, validation |
| `gen_data.py` | Rebuilds the 5,000-listing dataset (see the note below) |
| `train_model.py` | Cleans the raw file (removes 143 duplicates), trains and compares the six models, saves the Random Forest |
| `data/used_bikes_raw.csv` | 5,143 raw rows (includes 143 exact duplicates) |
| `data/used_bikes.csv` | The 5,000 cleaned listings, 15 fields |
| `model/bikeworth_model.joblib`, `model/metrics.json` | Saved model and all metrics shown in the app |
| `.streamlit/config.toml` | Dark theme with the orange accent |

To retrain: `python train_model.py`. To rebuild the data and retrain: `python gen_data.py && python train_model.py`.

## Method (as in Chapter 5 of the report)

* Age = 2026 - model year. Categories are one-hot encoded. Six numeric fields are standardised with the training means and standard deviations. Missing ex-showroom prices are imputed with the brand median.
* 4,000 / 1,000 train / test split, plus 5-fold cross-validation on the training rows.
* Models: Linear, Ridge, KNN (K = 7), Decision Tree, Random Forest, Gradient Boosting.
* Final model: Random Forest, 200 trees, maximum depth 18, at least 2 listings per leaf.
* Estimate = mean of the 200 trees. Likely range = 10th to 90th percentile of the tree outputs.

## Important note about the data

The original listings file was not available when this app was built. `gen_data.py`
therefore **generates a synthetic dataset** that reproduces the statistics published in the
report: 5,000 listings, 12 brands and their price-band counts (Table 6.3), median price
Rs. 52,000, mean about Rs. 68,400, 1,240 missing ex-showroom prices, 312 missing mileage values,
37 listings priced above their ex-showroom price, 143 duplicates in the raw file, the ten most
expensive listings (Table 6.4) and the first record (Table 4.3).

Because the rows are generated, the model results are close to, but not identical with, the report.
If you have the real CSV, put it in `data/used_bikes_raw.csv` with the same 14 columns (without
`age_years`), delete `data/used_bikes.csv` and the `model/` files, and start the app: it will clean
the file and retrain on your real data. Make sure the report states how the data were obtained.

## Differences from the report's walkthrough

The report records two defects (Section 7.3): no input validation and no low-data warning. This app
already fixes both, as recommended in Chapter 10: inputs are limited to the ranges seen in the data,
and a warning appears for brands with fewer than 100 listings. It also shows the typical error for the
estimate's price band. If your report must show the original defects, remove `validate_inputs` and the
`min_value` / `max_value` arguments in `page_predictor`.
