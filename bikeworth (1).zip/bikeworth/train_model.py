"""
Train and compare the six regression models, then save the Random Forest.

Run:  python train_model.py
Creates: model/bikeworth_model.joblib and model/metrics.json
"""
import time

import pandas as pd

from bikeworth_core import (DATA_CLEAN, DATA_RAW, TARGET, prepare_data,
                            save_artifacts, train_all)


def main():
    t0 = time.time()
    raw = pd.read_csv(DATA_RAW)
    clean, info = prepare_data(raw)
    print(f"Loaded {info['raw_records']:,} raw records; removed "
          f"{info['duplicates_removed']} exact duplicates -> {len(clean):,} listings")
    clean.to_csv(DATA_CLEAN, index=False)

    artifact, metrics = train_all(clean, info)
    save_artifacts(artifact, metrics)

    print(f"\n{'Model':<20}{'MAE':>10}{'RMSE':>10}{'R2 test':>10}{'R2 5-fold':>11}{'MAPE %':>9}")
    for name, m in metrics["models"].items():
        print(f"{name:<20}{m['MAE']:>10,.0f}{m['RMSE']:>10,.0f}{m['R2']:>10.2f}"
              f"{m['R2_CV']:>11.2f}{m['MAPE']:>9.1f}")
    print("\nRandom Forest error by segment (MAPE %):")
    for k, v in metrics["segments_mape"].items():
        print(f"  {k:<40}{v:>6.1f}")
    print("\nFeature importance:")
    for k, v in list(metrics["importance"].items())[:6]:
        print(f"  {k:<20}{v:>6.2f}")
    print(f"  top-3 share: {metrics['top3_importance_share']:.0%}")
    print(f"RF R2 without ex-showroom price: {metrics['rf_r2_without_ex_showroom']:.2f}")
    print("Correlations:", {k: round(v, 2) for k, v in metrics["correlations"].items()})
    print(f"Done in {time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
