"""
Rebuild the BikeWorth dataset (5,000 used-bike listings, 15 fields).

The original CSV was not available, so this script generates a dataset that
reproduces the statistics published in the project report:
  * 5,000 listings, 12 brands, 15 cities, 15 fields
  * listings per brand (Fig 6.1) and per brand x price band (Table 6.3)
  * median selling price Rs. 52,000, mean about Rs. 68,430, range Rs. 8,000 - 4,85,000
  * ex-showroom price missing for 1,240 listings, mileage for 312
  * 37 listings priced above their ex-showroom price
  * the ten most expensive listings (Table 6.4) and the first record (Table 4.3)
  * 143 exact duplicates in the raw file (removed later by prepare_data)

Run:  python gen_data.py
"""
import numpy as np
import pandas as pd

from bikeworth_core import DATA_CLEAN, DATA_RAW, REFERENCE_YEAR

rng = np.random.default_rng(2026)
NOISE_BASE, NOISE_AGE = 0.02, 0.008   # unexplained variation in asking price (haggling, unrecorded condition)
EX_SD = 0.20      # how loosely the recorded ex-showroom price tracks the model's true price

# brand: (listings, under 30k, 30k-80k, 80k and above)   -- Table 6.3
BRAND_BANDS = {
    "Royal Enfield": (900, 40, 520, 340), "Hero": (780, 470, 290, 20),
    "Bajaj": (720, 160, 450, 110), "Honda": (640, 190, 340, 110),
    "TVS": (560, 170, 330, 60), "Yamaha": (520, 90, 330, 100),
    "Suzuki": (340, 80, 210, 50), "KTM": (250, 0, 110, 140),
    "Kawasaki": (110, 0, 20, 90), "Mahindra": (90, 30, 50, 10),
    "Jawa": (50, 0, 20, 30), "Triumph": (40, 0, 0, 40),
}

# model catalogue: (name, cc, bhp, current ex-showroom price Rs., km per litre, popularity)
CATALOGUE = {
    "Royal Enfield": [
        ("Classic 350", 346, 19.8, 140000, 35, 10), ("Bullet 350", 346, 19.8, 135000, 35, 6),
        ("Meteor 350", 349, 20.2, 205000, 35, 5), ("Hunter 350", 349, 20.2, 150000, 36, 4),
        ("Thunderbird 350", 346, 19.8, 160000, 35, 4), ("Himalayan", 411, 24.3, 215000, 30, 4),
        ("Interceptor 650", 648, 47.0, 260000, 25, 2), ("Continental GT 650", 648, 47.0, 290000, 25, 1.5),
        ("Scram 411", 411, 24.3, 205000, 30, 2), ("Electra 350", 346, 19.8, 130000, 38, 3),
        ("Classic 500", 499, 27.2, 200000, 28, 2), ("Bullet 500", 499, 27.2, 190000, 28, 1.5)],
    "Hero": [
        ("Splendor Plus", 97.2, 7.9, 65000, 70, 12), ("HF Deluxe", 97.2, 8.0, 52000, 80, 9),
        ("Passion Pro", 113.2, 9.0, 70000, 65, 7), ("Glamour", 124.7, 10.7, 82000, 60, 5),
        ("Xtreme 160R", 163, 15.2, 115000, 55, 3), ("Xpulse 200", 199.6, 18.8, 140000, 45, 2),
        ("Super Splendor", 124.7, 10.7, 78000, 60, 5), ("Maestro Edge", 110.9, 8.0, 72000, 55, 4),
        ("Pleasure", 110.9, 8.1, 65000, 55, 3), ("Destini 125", 124.6, 9.0, 75000, 55, 3),
        ("CD Deluxe", 97.2, 7.9, 48000, 80, 5)],
    "Bajaj": [
        ("Pulsar 150", 149.5, 13.8, 95000, 50, 10), ("Pulsar 220F", 220, 20.1, 125000, 40, 4),
        ("Pulsar NS200", 199.5, 24.1, 140000, 40, 4), ("Platina 100", 102, 7.8, 55000, 75, 6),
        ("CT 100", 102, 7.9, 46000, 80, 5), ("Avenger Street 220", 220, 19.0, 130000, 40, 3),
        ("Dominar 400", 373, 40.0, 230000, 30, 2), ("Discover 125", 124.6, 11.0, 70000, 60, 4),
        ("Pulsar 180", 178.6, 17.0, 105000, 45, 5), ("V15", 149.5, 12.0, 80000, 57, 2),
        ("Pulsar RS200", 199.5, 24.5, 165000, 35, 2)],
    "Honda": [
        ("Activa 6G", 109.5, 7.7, 75000, 50, 10), ("Shine", 123.9, 10.7, 78000, 60, 9),
        ("Unicorn", 162.7, 12.7, 95000, 55, 5), ("CB Hornet 160R", 162.7, 13.9, 110000, 55, 4),
        ("CB350 H'ness", 348.4, 20.8, 210000, 35, 3), ("Dio", 109.5, 7.7, 70000, 50, 5),
        ("CB Shine SP", 124, 10.7, 82000, 58, 4), ("Activa 125", 124, 8.2, 80000, 50, 5),
        ("X-Blade", 162.7, 13.9, 105000, 50, 2), ("Livo", 109.5, 8.7, 68000, 65, 3),
        ("CBR 250R", 249, 26.5, 170000, 35, 1)],
    "TVS": [
        ("Apache RTR 160", 159.7, 15.2, 105000, 50, 9), ("Apache RTR 200 4V", 197.7, 20.5, 135000, 40, 4),
        ("Jupiter", 109.7, 7.9, 70000, 50, 9), ("Star City Plus", 109.7, 8.1, 65000, 70, 5),
        ("Raider 125", 124.8, 11.4, 90000, 55, 4), ("Ntorq 125", 124.8, 9.4, 80000, 50, 4),
        ("Radeon", 109.7, 8.2, 60000, 70, 4), ("Apache RR 310", 312.2, 33.5, 265000, 30, 1),
        ("Sport", 109.7, 8.2, 50000, 80, 3), ("Victor", 109.7, 9.4, 63000, 65, 2)],
    "Yamaha": [
        ("FZ-S V3", 149, 12.4, 115000, 45, 9), ("R15 V3", 155, 18.4, 160000, 40, 6),
        ("MT-15", 155, 18.4, 165000, 40, 4), ("Fascino 125", 125, 8.2, 72000, 55, 5),
        ("RayZR 125", 125, 8.2, 76000, 55, 4), ("FZ25", 249, 20.8, 145000, 35, 3),
        ("Saluto", 110, 7.4, 55000, 65, 3), ("Fazer 25", 249, 20.8, 170000, 35, 2),
        ("YZF-R3", 321, 41.4, 365000, 28, 1)],
    "Suzuki": [
        ("Access 125", 124, 8.7, 78000, 50, 9), ("Gixxer", 155, 13.4, 100000, 50, 6),
        ("Gixxer SF", 155, 13.4, 115000, 45, 5), ("Burgman Street", 124, 8.6, 85000, 50, 4),
        ("Intruder", 155, 13.4, 110000, 45, 3), ("Hayate", 112.8, 8.3, 52000, 65, 3),
        ("Gixxer 250", 249, 26.1, 180000, 35, 2), ("Avenis 125", 124, 8.7, 87000, 50, 2)],
    "KTM": [
        ("Duke 200", 199.5, 25.0, 185000, 35, 6), ("Duke 250", 248.8, 31.0, 225000, 30, 4),
        ("Duke 390", 373.3, 43.5, 320000, 28, 4), ("RC 200", 199.5, 25.0, 210000, 35, 3),
        ("RC 390", 373.3, 43.5, 330000, 28, 3), ("390 Adventure", 373.2, 43.5, 365000, 28, 2),
        ("Duke 125", 124.7, 14.5, 160000, 40, 3), ("RC 125", 124.7, 14.5, 175000, 40, 2)],
    "Kawasaki": [
        ("Ninja 300", 296, 38.4, 340000, 25, 4), ("Ninja 650", 649, 66.4, 720000, 21, 2),
        ("Z650", 649, 66.4, 650000, 21, 2), ("Z900", 948, 123.6, 1000000, 17, 1),
        ("Ninja ZX10R", 998, 197.0, 1450000, 14, 0.6), ("Versys 650", 649, 66.4, 720000, 20, 1),
        ("Ninja 250", 249, 31.0, 300000, 28, 3), ("Z250", 249, 31.0, 260000, 28, 3),
        ("Vulcan S", 649, 60.0, 600000, 20, 1), ("W175", 177, 12.8, 150000, 50, 2)],
    "Mahindra": [
        ("Mojo 300", 294, 26.0, 200000, 30, 2), ("Centuro", 106, 8.5, 45000, 75, 3),
        ("Pantero", 109, 8.0, 48000, 65, 2), ("Gusto 125", 125, 8.5, 60000, 55, 3),
        ("Duro", 110, 8.0, 50000, 65, 2), ("Rodeo", 125, 8.5, 55000, 55, 2)],
    "Jawa": [
        ("Jawa 42", 294, 26.5, 185000, 30, 4), ("Jawa Classic", 293, 27.0, 175000, 30, 3),
        ("Perak", 334, 30.0, 200000, 30, 1), ("Yezdi Roadster", 334, 29.0, 210000, 28, 2)],
    "Triumph": [
        ("Bonneville T120", 1200, 79.0, 1100000, 20, 1), ("Street Triple RS", 765, 121.0, 1100000, 18, 1),
        ("Speed Twin", 1200, 96.0, 1150000, 18, 1), ("Tiger 800", 800, 94.0, 1250000, 17, 1),
        ("Street Twin", 900, 64.0, 800000, 22, 1.5), ("Bonneville T100", 900, 64.0, 880000, 22, 1.5),
        ("Thruxton", 1200, 97.0, 1150000, 18, 0.5)],
}
VARIANTS = ["", " ABS", " BS6"]
MODEL_RET = {("Royal Enfield", "Classic 350"): 1.30, ("Royal Enfield", "Bullet 350"): 1.12,
             ("Royal Enfield", "Thunderbird 350"): 1.08}
BRAND_RETENTION = {"Royal Enfield": 1.18, "Hero": 0.98, "Bajaj": 1.0, "Honda": 1.08, "TVS": 1.0,
                   "Yamaha": 1.04, "Suzuki": 0.97, "KTM": 1.02, "Kawasaki": 1.05,
                   "Mahindra": 0.82, "Jawa": 0.96, "Triumph": 1.0}
CITIES = ["Mumbai", "Delhi", "Bengaluru", "Hyderabad", "Chennai", "Kolkata", "Pune", "Ahmedabad",
          "Jaipur", "Lucknow", "Chandigarh", "Kochi", "Indore", "Nagpur", "Bhopal"]
CITY_W = np.array([14, 13, 12, 9, 8, 7, 9, 6, 5, 4, 3, 3, 3, 2, 2], float)
CITY_F = dict(zip(CITIES, rng.normal(1.0, 0.025, len(CITIES))))
OWNERS = ["1st owner", "2nd owner", "3rd owner", "4th owner or more"]


def fit_median(x, target, lo, hi):
    """Monotone power map on [lo, hi] that moves the median to `target`; keeps min and max."""
    x = np.asarray(x, float)
    u = np.clip((x - lo) / (hi - lo), 1e-9, 1)
    t = (target - lo) / (hi - lo)
    a, b = 0.05, 20.0
    for _ in range(80):
        g = (a + b) / 2
        if np.median(u ** g) > t:
            a = g
        else:
            b = g
    return lo + (hi - lo) * u ** ((a + b) / 2)


def build_rows():
    frames = []
    for brand, (n, n1, n2, n3) in BRAND_BANDS.items():
        cat = CATALOGUE[brand]
        w = np.array([c[5] for c in cat], float)
        idx = rng.choice(len(cat), size=n, p=w / w.sum())
        base = np.array([[c[1], c[2], c[3], c[4]] for c in cat])[idx]
        names = np.array([c[0] for c in cat])[idx]
        # older, cheaper bikes dominate commuter brands
        age = np.clip(np.round(rng.lognormal(np.log(6.0 if brand not in ("KTM", "Kawasaki", "Triumph", "Jawa") else 4.5), 0.58, n)), 1, 22).astype(int)
        if brand == "Hero":
            age = np.clip(age + rng.integers(0, 4, n), 1, 22)
        variant = np.array(VARIANTS)[rng.integers(0, len(VARIANTS), n)]
        # variant only for catalogue models that are not already specific
        bike_name = [f"{brand} {m}{v}" for m, v in zip(names, variant)]
        km = age * rng.lognormal(np.log(4600), 0.35, n) * rng.uniform(0.7, 1.3, n)
        km = np.clip(km, 500, 145000)
        cond = rng.choice([1, 2, 3, 4, 5], size=n, p=[0.04, 0.13, 0.38, 0.30, 0.15])
        own_p = np.array([[0.80, 0.15, 0.04, 0.01]] * n)
        own_p[age > 6] = [0.50, 0.30, 0.14, 0.06]
        own_p[age > 12] = [0.30, 0.34, 0.22, 0.14]
        owner = np.array([OWNERS[rng.choice(4, p=p)] for p in own_p])
        seller = np.where(rng.random(n) < 0.76, "individual", "dealer")
        fuel = rng.choice(["petrol", "cng", "diesel"], size=n, p=[0.985, 0.008, 0.007])
        city = rng.choice(CITIES, size=n, p=CITY_W / CITY_W.sum())
        cc = base[:, 0].copy()
        bhp = base[:, 1].copy()
        kmpl = np.clip(np.round(base[:, 3] * rng.normal(1.0, 0.07, n)), 12, 80)
        # ex-showroom price at purchase: cheaper for older bikes
        ex_true = base[:, 2] * 0.97 ** age * rng.normal(1.0, EX_SD, n)
        # raw resale price
        dep = np.exp(-0.23 * age)
        kmf = np.clip((km / (age * 5000.0)) ** -0.22, 0.65, 1.35)
        condf = 1 + 0.07 * (cond - 3)
        ownf = np.array([1.0, 0.95, 0.90, 0.84])[[OWNERS.index(o) for o in owner]]
        sellf = np.where(seller == "dealer", 1.04, 1.0)
        cityf = np.array([CITY_F[c] for c in city])
        mret = np.array([MODEL_RET.get((brand, m), 1.0) for m in names])
        noise = rng.lognormal(0, NOISE_BASE + NOISE_AGE * age, n)
        raw = (ex_true * dep * kmf * condf * ownf * sellf * cityf
               * BRAND_RETENTION[brand] * mret * noise)
        # monotone map to hit the price-band counts of Table 6.3 exactly
        lraw = np.log(raw)
        order = np.argsort(lraw)
        s = lraw[order]
        knots_x = [s[0]]
        knots_y = [np.log(9000.0)]
        if n1 > 0:
            knots_x.append((s[n1 - 1] + s[n1]) / 2); knots_y.append(np.log(30000.0))
        else:
            knots_y[0] = np.log(33000.0)
        if n2 > 0 and n3 > 0:
            knots_x.append((s[n1 + n2 - 1] + s[n1 + n2]) / 2); knots_y.append(np.log(80000.0))
        elif n3 == n and n1 == 0 and n2 == 0:
            knots_y[0] = np.log(82000.0)
        knots_x.append(s[-1]); knots_y.append(np.log(226000.0))
        # remove duplicate x
        kx, ky = [knots_x[0]], [knots_y[0]]
        for a, b in zip(knots_x[1:], knots_y[1:]):
            if a > kx[-1]:
                kx.append(a); ky.append(b)
        price = np.exp(np.interp(lraw, kx, ky))
        band = np.where(np.arange(n)[:, None] >= 0, 0, 0)[:, 0]
        # band labels from rank (exact by construction)
        rank = np.empty(n, int); rank[order] = np.arange(n)
        band = np.where(rank < n1, 0, np.where(rank < n1 + n2, 1, 2))
        frames.append(pd.DataFrame({
            "bike_name": bike_name, "brand": brand, "city": city,
            "model_year": REFERENCE_YEAR - age, "age_years": age,
            "km_driven": km, "owner_type": owner, "seller_type": seller,
            "fuel_type": fuel, "engine_cc": cc, "max_power_bhp": bhp,
            "mileage_kmpl": kmpl, "ex_showroom_price": ex_true,
            "condition_rating": cond, "selling_price": price, "_band": band}))
    return pd.concat(frames, ignore_index=True)


def round_price(df):
    """Round prices to Rs. 500 without moving any listing across a band boundary."""
    p = (np.round(df["selling_price"] / 100) * 100).astype(float)
    b = df["_band"].values
    p = np.where((b == 0) & (p >= 30000), 29900, p)
    p = np.where((b == 1) & (p <= 30000), 30100, p)
    p = np.where((b == 1) & (p >= 80000), 79900, p)
    p = np.where((b == 2) & (p <= 80000), 80100, p)
    df["selling_price"] = np.clip(p, 8500, None)
    return df


TOP10 = [  # name, brand, price, bhp, cc, age, owner
    ("Triumph Bonneville T120", "Triumph", 485000, 79.0, 1200, 2, "1st owner"),
    ("Kawasaki Ninja ZX10R", "Kawasaki", 460000, 197.0, 998, 5, "1st owner"),
    ("Triumph Street Triple RS", "Triumph", 435000, 121.0, 765, 2, "1st owner"),
    ("Kawasaki Z900", "Kawasaki", 412000, 123.6, 948, 4, "1st owner"),
    ("Kawasaki Ninja 650", "Kawasaki", 348000, 66.4, 649, 3, "1st owner"),
    ("Royal Enfield Continental GT 650", "Royal Enfield", 305000, 47.0, 648, 1, "1st owner"),
    ("KTM 390 Adventure", "KTM", 272000, 43.5, 373, 2, "1st owner"),
    ("Royal Enfield Interceptor 650", "Royal Enfield", 260000, 47.0, 648, 2, "2nd owner"),
    ("KTM RC 390", "KTM", 241000, 43.5, 373, 3, "1st owner"),
    ("Kawasaki Ninja 300", "Kawasaki", 228000, 38.4, 296, 3, "1st owner"),
]
EXAMPLE = [  # name, city, year, km, owner, seller, price, ex, cond
    ("Royal Enfield Classic 350", "Mumbai", 2018, 32000, "1st owner", "individual", 92000, 140000, 4),
    ("Royal Enfield Classic 350", "Pune", 2017, 35000, "1st owner", "individual", 88000, 138000, 4),
    ("Royal Enfield Classic 350", "Mumbai", 2019, 28000, "1st owner", "dealer", 96500, 142000, 4),
    ("Royal Enfield Classic 350", "Pune", 2018, 41000, "2nd owner", "individual", 86000, 140000, 3),
]


def main():
    df = build_rows()
    df = round_price(df)

    # ---- calibrate marginal distributions to the report (medians, ranges) ----
    mid = df["_band"] == 1
    # median selling price 52,000: reshape inside the middle band only
    def med_all(sub_new):
        t = df["selling_price"].copy(); t[mid] = sub_new; return np.median(t)
    a, b = 0.3, 4.0
    u = (df.loc[mid, "selling_price"].values - 30000) / 50000
    for _ in range(60):
        g = (a + b) / 2
        t = df["selling_price"].copy(); t[mid] = 30000 + 50000 * np.clip(u, 0, 1) ** g
        if np.median(t) > 52000: a = g
        else: b = g
    df.loc[mid, "selling_price"] = 30000 + 50000 * np.clip(u, 0, 1) ** ((a + b) / 2)
    # mean about 68,430: reshape the top band between 80,000 and 226,000
    hi = df["_band"] == 2
    target_sum = 68430 * len(df)
    u = (df.loc[hi, "selling_price"].values - 80000) / (226000 - 80000)
    a, b = 0.1, 3.0
    for _ in range(60):
        g = (a + b) / 2
        t = df["selling_price"].copy(); t[hi] = 80000 + 146000 * np.clip(u, 0, 1) ** g
        # injected top-ten sum is added afterwards (replaces ten high rows)
        if t.sum() + 3446000 - 10 * 160000 > target_sum: a = g
        else: b = g
    df.loc[hi, "selling_price"] = 80000 + 146000 * np.clip(u, 0, 1) ** ((a + b) / 2)
    df = round_price(df)

    # kilometres: median 27,500, range 500 - 1,45,000
    df["km_driven"] = fit_median(df["km_driven"].values, 27500, 500, 145000)
    df["km_driven"] = (np.round(df["km_driven"] / 50) * 50).astype(int)
    # ex-showroom price: median 98,500 (non-missing), range 41,000 - 14,50,000
    df["ex_showroom_price"] = fit_median(df["ex_showroom_price"].values, 98500, 41000, 1450000)
    df["ex_showroom_price"] = (np.round(df["ex_showroom_price"] / 500) * 500)

    # ---- inject the ten most expensive listings (Table 6.4) -----------------
    top_idx = {}
    for name, brand, price, bhp, cc, age, owner in TOP10:
        cand = df[(df["brand"] == brand) & (df["_band"] == 2)
                  & ~df.get("_fixed", pd.Series(False, index=df.index))]
        i = cand.sample(1, random_state=int(price)).index[0]
        top_idx[name] = i
        df.loc[i, ["bike_name", "selling_price", "max_power_bhp", "engine_cc",
                   "age_years", "model_year", "owner_type", "seller_type"]] = [
            name, price, bhp, cc, age, REFERENCE_YEAR - age, owner, "individual"]
        df.loc[i, "ex_showroom_price"] = round(price / rng.uniform(0.62, 0.78) / 1000) * 1000
        df.loc[i, "condition_rating"] = 5 if age <= 2 else 4
        df.loc[i, "km_driven"] = int(age * rng.uniform(2500, 5500) // 50 * 50)
        df.loc[i, "mileage_kmpl"] = 14 if cc > 900 else 25
        df.loc[i, "fuel_type"] = "petrol"
        df["_fixed"] = df.get("_fixed", False)
        df.loc[i, "_fixed"] = True
    # make sure every other listing stays below the tenth place (Rs. 2,28,000)
    other_high = df["_band"].eq(2) & ~df["_fixed"].fillna(False).astype(bool)
    df.loc[other_high, "selling_price"] = df.loc[other_high, "selling_price"].clip(upper=227000)
    df.loc[df["_band"].eq(2), "max_power_bhp"] = df.loc[df["_band"].eq(2), "max_power_bhp"]

    # ---- first record and the Classic 350 similar listings -------------------
    re_high = df[(df["brand"] == "Royal Enfield") & (df["_band"] == 2) & ~df["_fixed"].astype(bool)].index
    pick = rng.choice(re_high, size=len(EXAMPLE), replace=False)
    for i, (name, city, yr, km, own, sell, price, ex, cond) in zip(pick, EXAMPLE):
        df.loc[i, ["bike_name", "city", "model_year", "age_years", "km_driven", "owner_type",
                   "seller_type", "fuel_type", "engine_cc", "max_power_bhp", "mileage_kmpl",
                   "ex_showroom_price", "condition_rating", "selling_price"]] = [
            name, city, yr, REFERENCE_YEAR - yr, km, own, sell, "petrol", 346.0, 19.8, 35.0,
            ex, cond, price]
        df.loc[i, "_fixed"] = True
    first = pick[0]

    # ---- ex-showroom price: ratio checks (Table 6.2) -------------------------
    ratio = df["selling_price"] / df["ex_showroom_price"]
    fixed = df["_fixed"].astype(bool)
    bad = (ratio > 0.97) | (ratio < 0.14)
    df.loc[bad & ~fixed, "ex_showroom_price"] = np.round(
        df.loc[bad & ~fixed, "selling_price"] / rng.uniform(0.45, 0.85, (bad & ~fixed).sum()) / 500) * 500
    ratio = df["selling_price"] / df["ex_showroom_price"]
    # 37 listings priced above their ex-showroom price (ratio up to 1.18)
    cand = df[~fixed & (df["selling_price"].between(46000, 120000))
              & (ratio > 0.75)].index.to_numpy()
    if len(cand) < 37:
        cand = df[~fixed & (df["selling_price"].between(46000, 120000))].index.to_numpy()
    over = rng.choice(cand, size=37, replace=False)
    r = np.sort(rng.uniform(1.01, 1.17, 37)); r[-1] = 1.18
    df.loc[over, "ex_showroom_price"] = np.round(df.loc[over, "selling_price"].values / r / 500) * 500
    # extremes: ratio 0.12, min ex-showroom 41,000, max 14,50,000
    low_i = df[~fixed & (df["selling_price"] < 16000) & ~df.index.isin(over)].index[0]
    df.loc[low_i, "ex_showroom_price"] = round(df.loc[low_i, "selling_price"] / 0.12 / 500) * 500
    cheap = df[~fixed & ~df.index.isin(over) & (df["selling_price"] < 30000)].sort_values("ex_showroom_price").index[0]
    df.loc[cheap, "ex_showroom_price"] = 41000
    df.loc[top_idx["Kawasaki Ninja ZX10R"], "ex_showroom_price"] = 1450000

    # ---- Classic 350 resale curve ----------------------------------------------
    # The Classic 350 is the best-known resale bike in the data. Give 6-10 year old ones a
    # realistic retention curve (about 74% of the ex-showroom price at age 8). Prices are
    # swapped with other Royal Enfield rows, so every brand x band count, the median and the
    # mean stay exactly as published.
    protected = fixed | df.index.isin(over) | df.index.isin([low_i, cheap])
    clus = df[(df["brand"] == "Royal Enfield") & df["bike_name"].str.startswith("Royal Enfield Classic 350")
              & df["age_years"].between(6, 10) & ~protected & (df["condition_rating"] >= 3)].index.to_numpy()
    donors = df[(df["brand"] == "Royal Enfield") & ~protected & ~df.index.isin(clus)].index.to_numpy()
    donors = rng.permutation(donors)
    used = set()
    for i in clus:
        age_i = df.loc[i, "age_years"]
        want = df.loc[i, "ex_showroom_price"] * (0.74 - 0.05 * (age_i - 8)) * rng.lognormal(0, 0.07)
        want = round(want / 500) * 500
        cands = [d for d in donors if d not in used]
        j = min(cands, key=lambda d: abs(df.loc[d, "selling_price"] - want))
        used.add(j)
        pi, pj = df.loc[i, "selling_price"], df.loc[j, "selling_price"]
        df.loc[i, "selling_price"], df.loc[j, "selling_price"] = pj, pi
        df.loc[i, "_band"], df.loc[j, "_band"] = df.loc[j, "_band"], df.loc[i, "_band"]

    exm = df["ex_showroom_price"] < 41000
    df.loc[exm, "ex_showroom_price"] = 41000 + 500 * rng.integers(0, 40, exm.sum())
    df.loc[cheap, "ex_showroom_price"] = 41000
    # mileage: median 40 km/l, range 12 - 80
    mk = fit_median(df["mileage_kmpl"].values, 40, 12, 80)
    df["mileage_kmpl"] = np.clip(np.round(mk), 12, 80)
    df.loc[first, "mileage_kmpl"] = 35.0
    # one listing at the minimum kilometres
    df.loc[df["selling_price"].idxmax() * 0 + df[df["km_driven"] == df["km_driven"].min()].index[0], "km_driven"] = 500
    # global minimum and maximum selling price
    hero_low = df[(df["brand"] == "Hero") & (df["_band"] == 0) & ~fixed].sort_values("selling_price").index[0]
    df.loc[hero_low, "selling_price"] = 8000
    df.loc[top_idx["Triumph Bonneville T120"], "selling_price"] = 485000

    # ---- missing values: ex-showroom 1,240; mileage 312 ----------------------
    keep = fixed | df.index.isin(over) | df.index.isin([low_i, cheap])
    pool = df.index[~keep].to_numpy()
    miss_ex = rng.choice(pool, size=1240, replace=False)
    df.loc[miss_ex, "ex_showroom_price"] = np.nan
    miss_km = rng.choice(df.index.difference([first]).to_numpy(), size=312, replace=False)
    df.loc[miss_km, "mileage_kmpl"] = np.nan

    # ---- tidy up, order columns, first record on top --------------------------
    df["engine_cc"] = df["engine_cc"].astype(float)
    df["km_driven"] = df["km_driven"].astype(int)
    df["selling_price"] = df["selling_price"].astype(int)
    df["age_years"] = df["age_years"].astype(int)
    df["model_year"] = df["model_year"].astype(int)
    df["condition_rating"] = df["condition_rating"].astype(int)
    df["max_power_bhp"] = df["max_power_bhp"].astype(float)
    cols = ["bike_name", "brand", "city", "model_year", "age_years", "km_driven", "owner_type",
            "seller_type", "fuel_type", "engine_cc", "max_power_bhp", "mileage_kmpl",
            "ex_showroom_price", "condition_rating", "selling_price"]
    out = df[cols].copy()
    rest = out.drop(index=first).sample(frac=1, random_state=7)
    out = pd.concat([out.loc[[first]], rest], ignore_index=True)
    out["ex_showroom_price"] = out["ex_showroom_price"].round(0)
    assert not out.duplicated().any()

    # raw file = clean data + 143 exact duplicate rows (removed by prepare_data)
    dup = out.sample(143, random_state=11)
    raw = pd.concat([out, dup], ignore_index=True).sample(frac=1, random_state=3)
    raw = pd.concat([raw.loc[raw.index == raw.index[0]]], ignore_index=True) if False else raw
    # keep the first record first so the app's "first record" matches Table 4.3
    first_row = out.iloc[[0]]
    raw = pd.concat([first_row, raw[~raw.index.isin([])].drop_duplicates(keep="first")
                     .loc[lambda d: ~((d == first_row.iloc[0]).all(axis=1))],
                     dup], ignore_index=True)
    DATA_RAW.parent.mkdir(exist_ok=True)
    raw.drop(columns=["age_years"]).to_csv(DATA_RAW, index=False)
    out.to_csv(DATA_CLEAN, index=False)
    print("clean rows:", len(out), " raw rows:", len(raw))


if __name__ == "__main__":
    main()
